function selecionarCidade(nome) {
	alert('Cidade selecionada: \n' + nome.toUpperCase());
}
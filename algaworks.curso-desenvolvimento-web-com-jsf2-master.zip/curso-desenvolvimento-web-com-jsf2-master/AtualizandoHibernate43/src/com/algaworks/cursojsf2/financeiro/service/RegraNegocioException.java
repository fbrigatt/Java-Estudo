package com.algaworks.cursojsf2.financeiro.service;

public class RegraNegocioException extends Exception {

	public RegraNegocioException(String message) {
		super(message);
	}
	
}

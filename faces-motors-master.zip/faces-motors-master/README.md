faces-motors
============

Código fonte do [Livro "Aplicações Java para a web com JSF e JPA" da Casa do Código](http://www.casadocodigo.com.br/products/livro-jsf-jpa).

Para facilitar, os jars já estão no projeto, mas o projeto usa o [Ivy](http://ant.apache.org/ivy/), que é um gerenciador de dependências para Java.

**Frameworks utilizados** (as versões serão atualizadas de tempos em tempos)
- JSF 2.2.0
- JPA 2 (Hibernate 4.2.2)
- Primefaces 3.3.1
- Bean Validation 1.0

Sinta-se a vontade para criar "issues" no github para que possamos melhorar o projeto.
O projeto ainda está sem menu, então a navegação está via url. Em breve um update nesse sentido.

Em breve estarei subindo a parte de testes para JSF com [JSFUnit](http://www.jboss.org/jsfunit) e [Arquillian](http://arquillian.org).

Procurarei linkar os conteúdos desse código com posts no [meu blog](http://gilliard.eti.br), assim além do código vou disponibilizar um conteúdo mais explicativo.
package br.com.museuid.model;

public class Guias {

}

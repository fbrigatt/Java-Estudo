**MaterialFX - Material design for javafx**

Cascading Style Sheet that brings Google Material Design appearance to JavaFX desktop applications.
So far we have the main controls covered, we are now working on containers and charts.

Our goal is to do the styling using only CSS, making it easy to use on existing applications.
